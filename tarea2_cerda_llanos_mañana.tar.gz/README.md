# Tarea 2 Algoritmos y Complejidad

#### Integrantes:

- Alfredo Llanos 201804536-5
- Sofia Mañana 201804535-7
- Fernanda Cerda 201804567-5
    
#### Ejecución

- texto.txt es el caso de prueba para el problema 1.
- texto2.txt es el caso de prueba para el problema 2.
   